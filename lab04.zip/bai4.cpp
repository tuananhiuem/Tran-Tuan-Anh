#include <iostream>

using namespace std;

int main() {
    double diem;

    cout << "Nhap diem (0 - 10): ";
    cin >> diem;
    if (diem < 0.0 || diem > 10.0) {
        cout << "Diem khong hop le" << endl;
    }
    else {
        if (diem >= 8.0) {
            cout << "Gioi" << endl;
        }
        else if (diem >= 6.5) {
            cout << "Kha" << endl;
        }
        else if (diem >= 5.0) {
            cout << "Dat" << endl;
        }
        else {
            cout << "Chua dat" << endl;
        }
    }

    return 0;
}