#include <iostream>

using namespace std;

int main() {
    long long giaA, giaB;

    cout << "Nhap gia ban tai cua hang A va B: ";
    cin >> giaA >> giaB;

    if (giaA < giaB) {
        cout << "A re hon, chenh lech: " << giaB - giaA << " dong" << endl;
    }
    else if (giaA > giaB) {
        cout << "B re hon, chenh lech: " << giaA - giaB << " dong" << endl;
    }
    else {
        cout << "Hai noi cung gia, chenh lech: 0 dong" << endl;
    }

    return 0;
}