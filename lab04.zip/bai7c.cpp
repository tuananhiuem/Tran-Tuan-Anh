#include <iostream>
using namespace std;

int main() {
    double diem = 12; // Thử với -1, 5, 12
    if (diem >= 0 && diem <= 10) { // Sửa biểu thức ghép
        cout << "Hop le\n";
    }
    else {
        cout << "Khong hop le\n";
    }
    return 0;
}