#include <iostream>

using namespace std;

int main() {
    int soGio, coThe;
    long long tienDua;

    cout << "Nhap so gio, the thanh vien (1: Co, 0: Khong) va tien đưa: ";
    cin >> soGio >> coThe >> tienDua;
    bool hopLe = (soGio >= 1 && soGio <= 12) &&
        (coThe == 0 || coThe == 1) &&
        (tienDua >= 0 && tienDua <= 5000000);

    if (!hopLe) {
        cout << "Loi: Du lieu nhap vao khong hop le!" << endl;
        return 0; 
    }
    long long tienGoc = soGio * 60000LL;
    long long tienGiam = 0;

    if (soGio >= 3 && coThe == 1) {
        tienGiam = 30000;
    }
    else if (soGio >= 3 && coThe == 0) {
        tienGiam = 15000;
    }
    else {
        tienGiam = 0;
    }
    long long tienPhaiTra = tienGoc - tienGiam;

    cout << "\n--- HOA DON THUE SAN ---" << endl;
    cout << "Tien goc: " << tienGoc << " dong" << endl;
    cout << "Tien giam: " << tienGiam << " dong" << endl;
    cout << "Tien phai tra: " << tienPhaiTra << " dong" << endl;

    if (tienDua >= tienPhaiTra) {
        long long tienTraLai = tienDua - tienPhaiTra;
        cout << "Tien tra lai: " << tienTraLai << " dong" << endl;
    }
    else {
        long long tienConThieu = tienPhaiTra - tienDua;
        cout << "So tien con thieu: " << tienConThieu << " dong" << endl;
    }

    return 0;
}