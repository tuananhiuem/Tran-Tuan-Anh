#include <iostream>
using namespace std;

int main() {
    double diem = 4; // Thử với 4 hoặc 5
    if (diem >= 5) {  // Đã xóa dấu ';' sau if
        cout << "Dat\n";
    }
    return 0;
}