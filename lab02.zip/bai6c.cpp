#include <iostream>
using namespace std;

int main() {
    char khuVuc = 'A';
    cout << khuVuc << "\n";
    return 0;
}
//Nguyên nhân: Khai báo ký tự A dùng dấu ngoặc kép "" (chuỗi) thay vì ngoặc đơn '' và tên biến KhuVuc bị viết hoa sai so với khuVuc