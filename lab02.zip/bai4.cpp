#include <iostream>

using namespace std;

int main() {
    int n, k;
    cout << "Nhap so san pham (n): ";
    cin >> n;
    cout << "Nhap suc chua moi thung (k): ";
    cin >> k;
    int soThungDay = n / k;
    int soDu = n % k;
    cout << "So thung day: " << soThungDay << endl;
    cout << "So san pham con du: " << soDu << endl;
    cout << "Kiem tra tong: " << soThungDay * k + soDu << endl;
    return 0;
}