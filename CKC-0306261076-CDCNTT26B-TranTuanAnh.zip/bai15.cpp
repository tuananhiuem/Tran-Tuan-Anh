
#include <iostream>
using namespace std;

int main() {
    int namSinh, tuoi;

    cout << "Nhap nam sinh: ";
    cin >> namSinh;

    tuoi = 2026 - namSinh;

    if (namSinh <= 0 || namSinh > 2026) {
        cout << "Nam sinh khong hop le";
    }
    else if (tuoi >= 18) {
        cout << "Da du 18 tuoi";
    }
    else {
        cout << "Chua du 18 tuoi";
    }

    return 0;
}
