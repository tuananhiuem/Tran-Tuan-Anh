
#include <iostream>
using namespace std;

int main() {
    double a, b;

    cout << "Nhap a va b: ";
    cin >> a >> b;

    if (a != 0) {
        cout << "Phuong trinh co nghiem x = " << -b / a;
    }
    else if (b == 0) {
        cout << "Phuong trinh co vo so nghiem";
    }
    else {
        cout << "Phuong trinh vo nghiem";
    }

    return 0;
}
