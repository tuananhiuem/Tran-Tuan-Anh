#include <iostream>
using namespace std;

int main() {
    double dai, rong, chuVi;

    cout << "Nhap chieu dai: ";
    cin >> dai;
    cout << "Nhap chieu rong: ";
    cin >> rong;

    chuVi = 2 * (dai + rong);

    cout << "Chu vi hinh chu nhat = " << chuVi;

    return 0;
}