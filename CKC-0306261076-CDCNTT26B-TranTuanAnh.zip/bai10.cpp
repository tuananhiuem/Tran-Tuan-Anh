
#include <iostream>
#include <string>
using namespace std;

int main() {
    string tenSP;
    int soLuong;
    double donGia, tien, thue, tongTien;

    cout << "Nhap ten san pham: ";
    getline(cin, tenSP);

    cout << "Nhap so luong: ";
    cin >> soLuong;

    cout << "Nhap don gia: ";
    cin >> donGia;

    tien = soLuong * donGia;
    thue = tien * 0.10;
    tongTien = tien + thue;

    cout << "San pham: " << tenSP << endl;
    cout << "Tien hang = " << tien << endl;
    cout << "Thue VAT = " << thue << endl;
    cout << "Tong tien phai tra = " << tongTien << endl;

    return 0;
}
