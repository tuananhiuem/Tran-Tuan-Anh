
#include <iostream>
using namespace std;

int main() {
    int n, dao = 0;

    cout << "Nhap so nguyen co 5 chu so: ";
    cin >> n;

    if (n < 10000 || n > 99999) {
        cout << "So khong hop le";
        return 0;
    }

    while (n > 0) {
        dao = dao * 10 + n % 10;
        n /= 10;
    }

    cout << "So dao = " << dao;

    return 0;
}
