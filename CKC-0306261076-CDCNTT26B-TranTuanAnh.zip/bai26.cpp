
#include <iostream>
using namespace std;

int main() {
    double a, b, c;

    cout << "Nhap ba canh: ";
    cin >> a >> b >> c;

    if (a <= 0 || b <= 0 || c <= 0 ||
        a + b <= c || a + c <= b || b + c <= a) {
        cout << "Khong tao thanh tam giac";
    }
    else if (a == b || a == c || b == c) {
        cout << "Tam giac can";
    }
    else {
        cout << "Tam giac khong can";
    }

    return 0;
}
