
#include <iostream>
using namespace std;

int main() {
    int n;
    int a, b, c, d;

    cout << "Nhap so nguyen co 4 chu so: ";
    cin >> n;

    if (n < 1000 || n > 9999) {
        cout << "So khong hop le";
        return 0;
    }

    a = n / 1000;
    b = n / 100 % 10;
    c = n / 10 % 10;
    d = n % 10;

    if (a != b && a != c && a != d &&
        b != c && b != d && c != d) {
        cout << "Yes";
    }
    else {
        cout << "No";
    }

    return 0;
}
