
#include <iostream>
using namespace std;

int main() {
    double a, b, c, delta;

    cout << "Nhap a, b, c: ";
    cin >> a >> b >> c;

    delta = b * b - 4 * a * c;

    cout << "Delta = " << delta;

    return 0;
}
