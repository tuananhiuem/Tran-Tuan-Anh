#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double dai, rong, duongCheo;

    cout << "Nhap chieu dai: ";
    cin >> dai;
    cout << "Nhap chieu rong: ";
    cin >> rong;

    duongCheo = sqrt(dai * dai + rong * rong);

    cout << "Duong cheo = " << duongCheo;

    return 0;
}