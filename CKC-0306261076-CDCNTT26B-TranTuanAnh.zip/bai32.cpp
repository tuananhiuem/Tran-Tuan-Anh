
#include <iostream>
using namespace std;

int main() {
    double luong, thue, luongRong;
    double thueSuat;

    cout << "Nhap luong (trieu dong): ";
    cin >> luong;

    if (luong < 0) {
        cout << "Luong khong hop le";
        return 0;
    }

    if (luong > 30) {
        thueSuat = 0.15;
    }
    else if (luong >= 15) {
        thueSuat = 0.10;
    }
    else {
        thueSuat = 0.05;
    }

    thue = luong * thueSuat;
    luongRong = luong - thue;

    cout << "Thue thu nhap = " << thue
        << " trieu dong" << endl;
    cout << "Luong rong = " << luongRong
        << " trieu dong" << endl;

    return 0;
}
