
#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    double a, b, c;

    cout << "Nhap ba canh: ";
    cin >> a >> b >> c;

    if (a <= 0 || b <= 0 || c <= 0) {
        cout << "Canh khong hop le";
        return 0;
    }

    if (a > b) swap(a, b);
    if (b > c) swap(b, c);
    if (a > b) swap(a, b);

    if (a + b <= c) {
        cout << "Khong tao thanh tam giac";
    }
    else if (a == b && b == c) {
        cout << "Tam giac deu";
    }
    else if (a * a + b * b == c * c) {
        if (a == b) cout << "Tam giac vuong can";
        else cout << "Tam giac vuong";
    }
    else if (a == b || b == c) {
        cout << "Tam giac can";
    }
    else {
        cout << "Tam giac thuong";
    }

    return 0;
}
