#include <iostream>
using namespace std;

int main() {
    double dai, rong, dienTich;

    cout << "Nhap chieu dai: ";
    cin >> dai;
    cout << "Nhap chieu rong: ";
    cin >> rong;

    dienTich = dai * rong;

    cout << "Dien tich hinh chu nhat = " << dienTich;

    return 0;
}