
#include <iostream>
using namespace std;

int main() {
    int n;

    cout << "Nhap so nguyen khong nho hon 100: ";
    cin >> n;

    if (n < 100) {
        cout << "So khong hop le";
        return 0;
    }

    cout << "Hang don vi = " << n % 10 << endl;
    cout << "Hang chuc = " << n / 10 % 10 << endl;
    cout << "Hang tram = " << n / 100 % 10 << endl;

    return 0;
}
