
#include <iostream>
#include <algorithm>
using namespace std;

int main() {
    double a, b, c;

    cout << "Nhap ba canh tam giac: ";
    cin >> a >> b >> c;

    if (a <= 0 || b <= 0 || c <= 0) {
        cout << "Ba canh khong hop le";
        return 0;
    }

    if (a > b) swap(a, b);
    if (b > c) swap(b, c);
    if (a > b) swap(a, b);

    if (a + b <= c) {
        cout << "Khong tao thanh tam giac";
    }
    else if (a * a + b * b == c * c) {
        cout << "Tam giac vuong";
    }
    else {
        cout << "Khong phai tam giac vuong";
    }

    return 0;
}
