
#include <iostream>
using namespace std;

int main() {
    int nam;

    cout << "Nhap nam: ";
    cin >> nam;

    if (nam <= 0) {
        cout << "Nam khong hop le";
    }
    else if (nam % 400 == 0 ||
        (nam % 4 == 0 && nam % 100 != 0)) {
        cout << "Day la nam nhuan";
    }
    else {
        cout << "Day khong phai nam nhuan";
    }

    return 0;
}
