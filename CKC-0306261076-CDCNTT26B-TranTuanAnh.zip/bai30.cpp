
#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double a, b, c, delta;
    double x1, x2;

    cout << "Nhap a, b, c: ";
    cin >> a >> b >> c;

    if (a == 0) {
        if (b != 0) {
            cout << "Phuong trinh bac nhat co nghiem x = "
                << -c / b;
        }
        else if (c == 0) {
            cout << "Phuong trinh co vo so nghiem";
        }
        else {
            cout << "Phuong trinh vo nghiem";
        }
    }
    else {
        delta = b * b - 4 * a * c;

        if (delta < 0) {
            cout << "Phuong trinh vo nghiem thuc";
        }
        else if (delta == 0) {
            x1 = -b / (2 * a);
            cout << "Nghiem kep x = " << x1;
        }
        else {
            x1 = (-b + sqrt(delta)) / (2 * a);
            x2 = (-b - sqrt(delta)) / (2 * a);

            cout << "x1 = " << x1 << endl;
            cout << "x2 = " << x2 << endl;
        }
    }

    return 0;
}
