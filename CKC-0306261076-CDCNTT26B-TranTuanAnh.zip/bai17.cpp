
#include <iostream>
using namespace std;

int main() {
    double a, b, c, d;
    double nhoNhat;

    cout << "Nhap 4 so thuc: ";
    cin >> a >> b >> c >> d;

    nhoNhat = a;

    if (b < nhoNhat) nhoNhat = b;
    if (c < nhoNhat) nhoNhat = c;
    if (d < nhoNhat) nhoNhat = d;

    cout << "So nho nhat = " << nhoNhat;

    return 0;
}
