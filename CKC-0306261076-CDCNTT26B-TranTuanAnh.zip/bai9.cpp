
#include <iostream>
#include <cmath>
using namespace std;

int main() {
    double x1, y1, x2, y2, khoangCach;

    cout << "Nhap toa do x1, y1: ";
    cin >> x1 >> y1;

    cout << "Nhap toa do x2, y2: ";
    cin >> x2 >> y2;

    khoangCach = sqrt((x2 - x1) * (x2 - x1)
        + (y2 - y1) * (y2 - y1));

    cout << "Khoang cach = " << khoangCach;

    return 0;
}
