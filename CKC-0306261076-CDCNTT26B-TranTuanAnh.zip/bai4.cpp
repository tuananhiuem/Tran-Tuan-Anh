
#include <iostream>
using namespace std;

int main() {
    const double PI = 3.141592653589793;
    double r, dienTich;

    cout << "Nhap ban kinh: ";
    cin >> r;

    dienTich = PI * r * r;

    cout << "Dien tich hinh tron = " << dienTich;

    return 0;
}
r;