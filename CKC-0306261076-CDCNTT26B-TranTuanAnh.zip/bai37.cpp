
#include <iostream>
using namespace std;

int main() {
    int n;
    int a, b, c, d, e;

    cout << "Nhap so nguyen co 5 chu so: ";
    cin >> n;

    if (n < 10000 || n > 99999) {
        cout << "So khong hop le";
        return 0;
    }

    a = n / 10000;
    b = n / 1000 % 10;
    c = n / 100 % 10;
    d = n / 10 % 10;
    e = n % 10;

    if (a % 2 != 0 && b % 2 != 0 &&
        c % 2 != 0 && d % 2 != 0 &&
        e % 2 != 0) {
        cout << "Tat ca cac chu so deu le";
    }
    else {
        cout << "Khong phai tat ca cac chu so deu le";
    }

    return 0;
}
