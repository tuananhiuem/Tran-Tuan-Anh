
#include <iostream>
using namespace std;

int main() {
    int n, tong = 0;

    cout << "Nhap so xe gom 5 chu so: ";
    cin >> n;

    if (n < 10000 || n > 99999) {
        cout << "So xe khong hop le";
        return 0;
    }

    while (n > 0) {
        tong += n % 10;
        n /= 10;
    }

    cout << "So nut = " << tong % 10;

    return 0;
}
