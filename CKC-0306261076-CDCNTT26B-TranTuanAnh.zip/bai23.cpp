
#include <iostream>
using namespace std;

int main() {
    int ngay, thang, nam;
    int soNgay;

    cout << "Nhap ngay, thang, nam: ";
    cin >> ngay >> thang >> nam;

    if (nam <= 0 || thang < 1 || thang > 12) {
        cout << "Ngay thang nam khong hop le";
        return 0;
    }

    switch (thang) {
    case 1: case 3: case 5:
    case 7: case 8: case 10: case 12:
        soNgay = 31;
        break;

    case 4: case 6: case 9: case 11:
        soNgay = 30;
        break;

    case 2:
        if (nam % 400 == 0 ||
            (nam % 4 == 0 && nam % 100 != 0)) {
            soNgay = 29;
        }
        else {
            soNgay = 28;
        }
        break;
    }

    if (ngay >= 1 && ngay <= soNgay) {
        cout << "Ngay thang nam hop le";
    }
    else {
        cout << "Ngay thang nam khong hop le";
    }

    return 0;
}
