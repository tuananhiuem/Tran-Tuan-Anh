
#include <iostream>
using namespace std;

int main() {
    int nam;

    cout << "Nhap nam: ";
    cin >> nam;

    if (nam > 0) {
        cout << "Nam hop le";
    }
    else {
        cout << "Nam khong hop le";
    }

    return 0;
}
