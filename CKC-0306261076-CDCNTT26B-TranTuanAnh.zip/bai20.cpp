
#include <iostream>
using namespace std;

int main() {
    int thang;

    cout << "Nhap thang: ";
    cin >> thang;

    if (thang >= 1 && thang <= 12) {
        cout << "Thang hop le";
    }
    else {
        cout << "Thang khong hop le";
    }

    return 0;
}
