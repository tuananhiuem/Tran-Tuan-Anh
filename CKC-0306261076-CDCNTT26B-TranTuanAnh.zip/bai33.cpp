
#include <iostream>
using namespace std;

int main() {
    int n, banDau, dao = 0;

    cout << "Nhap so nguyen co 5 chu so: ";
    cin >> n;

    if (n < 10000 || n > 99999) {
        cout << "So khong hop le";
        return 0;
    }

    banDau = n;

    while (n > 0) {
        dao = dao * 10 + n % 10;
        n = n / 10;
    }

    if (banDau == dao) {
        cout << "Day la so doi xung";
    }
    else {
        cout << "Day khong phai so doi xung";
    }

    return 0;
}
