
#include <iostream>
using namespace std;

int main() {
    int n;
    int a, b, c, d, e;
    int tong = 0;

    cout << "Nhap so nguyen co 5 chu so: ";
    cin >> n;

    if (n < 10000 || n > 99999) {
        cout << "So khong hop le";
        return 0;
    }

    a = n / 10000;
    b = n / 1000 % 10;
    c = n / 100 % 10;
    d = n / 10 % 10;
    e = n % 10;

    if (a % 2 != 0) tong += a;
    if (b % 2 != 0) tong += b;
    if (c % 2 != 0) tong += c;
    if (d % 2 != 0) tong += d;
    if (e % 2 != 0) tong += e;

    cout << "Tong cac chu so le = " << tong;

    return 0;
}
