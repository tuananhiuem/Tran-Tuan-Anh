
#include <iostream>
using namespace std;

int main() {
    int n;
    int a, b, c, d, e;
    int lonNhat;

    cout << "Nhap so nguyen co 5 chu so: ";
    cin >> n;

    if (n < 10000 || n > 99999) {
        cout << "So khong hop le";
        return 0;
    }

    a = n / 10000;
    b = n / 1000 % 10;
    c = n / 100 % 10;
    d = n / 10 % 10;
    e = n % 10;

    lonNhat = a;

    if (b > lonNhat) lonNhat = b;
    if (c > lonNhat) lonNhat = c;
    if (d > lonNhat) lonNhat = d;
    if (e > lonNhat) lonNhat = e;

    cout << "Chu so lon nhat = " << lonNhat;

    return 0;
}
