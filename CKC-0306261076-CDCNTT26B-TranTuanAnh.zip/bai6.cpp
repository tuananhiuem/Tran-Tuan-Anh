#include <iostream>
using namespace std;

int main() {
    int a, b, tam;

    cout << "Nhap hai so nguyen: ";
    cin >> a >> b;

    tam = a;
    a = b;
    b = tam;

    cout << "Sau khi hoan vi: ";
    cout << "a = " << a << ", b = " << b;

    return 0;
}