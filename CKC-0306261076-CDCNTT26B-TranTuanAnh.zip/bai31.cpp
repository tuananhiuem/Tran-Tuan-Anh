
#include <iostream>
using namespace std;

int main() {
    double diem;

    cout << "Nhap diem trung binh: ";
    cin >> diem;

    if (diem < 0 || diem > 10) {
        cout << "Diem khong hop le";
    }
    else if (diem >= 8) {
        cout << "Hoc luc gioi";
    }
    else if (diem >= 6.5) {
        cout << "Hoc luc kha";
    }
    else if (diem >= 5) {
        cout << "Hoc luc trung binh";
    }
    else {
        cout << "Hoc luc yeu";
    }

    return 0;
}
