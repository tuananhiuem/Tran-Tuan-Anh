
#include <iostream>
using namespace std;

int main() {
    double a, b;

    cout << "Nhap hai so thuc: ";
    cin >> a >> b;

    if (a > b) {
        cout << "So lon nhat la " << a;
    }
    else if (b > a) {
        cout << "So lon nhat la " << b;
    }
    else {
        cout << "Hai so bang nhau";
    }

    return 0;
}
