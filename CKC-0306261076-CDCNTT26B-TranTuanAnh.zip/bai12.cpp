
#include <iostream>
using namespace std;

int main() {
    double toan, ly, hoa;
    double hsToan, hsLy, hsHoa;
    double trungBinh;

    cout << "Nhap diem Toan va he so: ";
    cin >> toan >> hsToan;

    cout << "Nhap diem Ly va he so: ";
    cin >> ly >> hsLy;

    cout << "Nhap diem Hoa va he so: ";
    cin >> hoa >> hsHoa;

    if (hsToan + hsLy + hsHoa <= 0) {
        cout << "Tong he so khong hop le";
        return 0;
    }

    trungBinh = (toan * hsToan + ly * hsLy + hoa * hsHoa)
        / (hsToan + hsLy + hsHoa);

    cout << "Diem trung binh = " << trungBinh;

    return 0;
}
