
#include <iostream>
using namespace std;

int main() {
    int a, b, c, d;
    double trungBinh;

    cout << "Nhap 4 so nguyen: ";
    cin >> a >> b >> c >> d;

    trungBinh = (a + b + c + d) / 4.0;

    cout << "Trung binh cong = " << trungBinh;

    return 0;
}
