
#include <iostream>
using namespace std;

int main() {
    double a, b, dienTich;

    cout << "Nhap hai canh goc vuong: ";
    cin >> a >> b;

    dienTich = a * b / 2;

    cout << "Dien tich tam giac vuong = " << dienTich;

    return 0;
}
