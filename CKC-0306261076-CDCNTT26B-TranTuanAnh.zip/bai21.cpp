
#include <iostream>
using namespace std;

int main() {
    int ngay;

    cout << "Nhap ngay: ";
    cin >> ngay;

    if (ngay >= 1 && ngay <= 31) {
        cout << "Ngay hop le";
    }
    else {
        cout << "Ngay khong hop le";
    }

    return 0;
}
