#include <iostream>

using namespace std;

int main() {
    char ma;
    double khoiLuong;

    cout << "Nhap ma dich vu va khoi luong: ";
    cin >> ma >> khoiLuong;

    bool dungMa = (ma == 'N' || ma == 'n');
    bool dungKhoiLuong = (khoiLuong > 0 && khoiLuong <= 5);
    bool chapNhan = dungMa && dungKhoiLuong;

    if (chapNhan) {
        cout << "Nhan kien" << endl;
    }
    else {
        cout << "Khong nhan kien" << endl;
    }

    return 0;
}