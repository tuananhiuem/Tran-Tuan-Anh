#include <iostream>
using namespace std;

int main() {
    double chuVi = 30;
    double tongDay = chuVi;
    if (chuVi > 30) {
        tongDay += 2;
    }

    cout << tongDay << "\n";
    return 0;
}
// Bỏ dấu chấm phẩy thừa sau điều kiện if
